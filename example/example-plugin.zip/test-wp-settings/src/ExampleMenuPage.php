<?php

use Idearia\MenuPage;

class ExampleMenuPage extends MenuPage
{
    protected $label = 'Example Menu Page';

    protected $slug = 'example-menu-page';

    protected $capability = 'edit_posts';

    public function view()
    {
        echo '<h1>Hello world</h1>';
        echo '<p>';
        echo 'Questa pagina può essere vista solo dagli editor in su.';
        echo '</p>';
    }
}