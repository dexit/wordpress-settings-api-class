<?php
/**
 * Plugin Name:       Test WP Settings
 * Description:       Plugin x testare la libreria  idearia/wordpress-settings-api-class
 * Author:            Idearia SRL
 * Author URI:        https://www.idearia.it
 * Version:           1.0
 */

 // Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Composer
if ( file_exists( __DIR__ . '/vendor/autoload.php' ) ) {
	require_once __DIR__ . '/vendor/autoload.php';
}

// Includes
require 'src/ExampleMenuPage.php';
require 'src/ExampleSettingsPage.php';

// Carica pagine
new ExampleMenuPage;
new ExampleSettingsPage;
